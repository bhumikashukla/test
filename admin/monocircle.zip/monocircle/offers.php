<?php 
session_start();
if($_SESSION["myusername"]=="" && $_SESSION["mypassword"]=="")
{
header("location:index.php");
} 
include('in_header.php');
include('function.php');
if(isset($_REQUEST['task']) && $_REQUEST['task']=='delete' && $_REQUEST['id']!='' )
   {
        $sql="DELETE FROM `offers` WHERE `offer`=".$_REQUEST['id'];
		if(mysql_query($sql))
		{
	    
?>
<script>
alert("Offer has been deleted successfully.");
window.location.href = 'offers.php';
</script>
<?php 
   } 
 }
?>
	
       <div class="right">   
         <div class="center_mess">Manage Offers<div style="float:right;margin-right:10px;margin-bottom:10px;">  
         <a href="addoffer.php" style="text-decoration:underline; color:#066; white-space:nowrap;">Add Offer</a>        
   	 	 </div>
       </div>
       <?php
			$usertype=getUserType();
			$mid = $_SESSION['admin_id'];
			if($usertype!="merchant") {	
				$sql ="SELECT * FROM offers"; 
			}
			else
			{
				$sql ="SELECT * FROM offers WHERE merchantid = $mid"; 
			}
			$pager = new PS_Pagination($conn, $sql,100, 20, "param1=value1&param2=value2");
			$pager->setDebug(true);
			$rs1 = $pager->paginate();			 
         ?> 
		<table width="100%" border="0" cellspacing="0" cellpadding="5">
            <tr>
                <td colspan="6" id="user_status_mess"></td>
            </tr>
            <tr class="tr_dis">                
                <td valign="top" width="250px;"><strong>Offer Name</strong></td> 
				<td valign="top" width="250px;"><strong>Merchant Name</strong></td>
                <td valign="top" width="400px;"><strong>Offer Price</strong></td>
                <td valign="top" width="200px;"><strong>Action</strong></td>
            </tr>
        <?php
        if($rs1)
        {
              $i=0;
                  while($row = mysql_fetch_array($rs1))   
                   {$i=$i+1; ?> 
					<tr class="tr_dis1">
						<td  valign="top" class="td_dis1"><?php echo $row["offername"]; ?></td>
						<td  valign="top" class="td_dis1">Pizza Hut</td>
						<td valign="top" class="td_dis1"><?php echo "$".$row["priceafterdiscount"];?></td>                       
                        <td valign="top" class="td_dis1">
							<a href="addoffer.php?id=<?php echo $row['offerid']; ?>">EDIT</a>&nbsp;|&nbsp;<a href="users.php?task=delete&id=<?php echo $row['offerid']; ?>" onclick="return confirm('Are you sure? You want to delete this offer?');">DELETE</a>
						</td>            
					</tr>
                <?php }
                }
                else
                {?>
                    <tr class="td_dis">     
                        <td colspan="7" align="center" ><br /><br />No Offers Found</td>
                     </tr>
                     
            <?php	}?>
            		<tr class="td_dis">     
                        <td colspan="7" align="center"></td>
                     </tr>              		
              		<tr class="td_dis">     
                        <td colspan="7" align="center" style="padding-top:20px;"><?php echo $pager->renderFullNav()?></td>
                     </tr>                              
        	</table>			
		</div><!-- /right -->
<?php include('in_footer.php'); ?> 