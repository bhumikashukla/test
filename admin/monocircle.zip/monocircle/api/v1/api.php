<?php
OnLoad();
class funcs_code 
{
   var $conn="";
   var $dba="linkixvk_pinbitcoinsdev"; 
   var $host="localhost";
   var $user="linkixvk_pinbit";
   var $pass="pinbitcoins@13"; 
  
   public function connection()
   {
      $this->conn=mysql_connect($this->host,$this->user,$this->pass) or die(mysql_error());	
      $this->dba=mysql_select_db($this->dba,$this->conn) or die(mysql_error());	
   }
   	
   public function query($sql_q)
   {
      $result=mysql_query($sql_q);
      if(!$result){die(mysql_error());}else{return $result;}
   }  
}
function OnLoad()
{
    $method = $_GET['method'];
    if($method == 'SignIn')
    {
        SignIn();
    }   
    else if ($method == 'SocialSignIn')
    {
		SocialSignIn();
    }
    else if($method == 'SignOut')
    {
		SignOut();
    }
    else if($method == 'SignUp')
    {
		SignUp();
    }   
    else if($method == 'ChangePassword')
    {
		ChangePassword();
    } 
    else if($method == 'UpdateUserProfile')
    {
		UpdateUserProfile();
    }  
    else if($method == 'Search')
    {
		Search();
    }   
    else if($method == 'MarkAsFavorites')
    {
		MarkAsFavorites();
    }
    else if($method == 'MarkAsUnFavorites')
    {
		MarkAsUnFavorites();
    }
    else if($method == 'GetFavorites')
    {
		GetFavorites();
    }
    else if ($method == 'ForgetPassword')
    {
		ForgetPassword();
    }
    else if ($method == 'GetUserDetail')
    {
		GetUserDetail();
    }
    else if($method == 'MarkAsBlocked')
    {
		MarkAsBlocked();
    }
    else if($method == 'GetBlockedUsers')
    {
		GetBlockedUsers();
    }
    else if($method == 'iospushnotificationtest')
    {
		iospushnotificationtest();
    }
    else if($method == 'GetChatHistory')
    {
		GetChatHistory();
    }
    else if($method == 'ContactUs')
    {
		ContactUs();
    }
    else if($method == 'UpdatePhoto')
    {
		UpdatePhoto();
    }
    else if($method == 'UpdateSettings')
    {
		UpdateSettings();
    }

} 
//For Sign In
function SignIn()
{
    $obj=new funcs_code();
    $obj->connection();			
    $email = '';
    $pwd  = '';    
    $devicetoken = "";
    $devicetype = "";
    $lat = 0;
    $lng = 0;
    $output = '0';
    if(isset($_POST['email']))
    {
       $email = $_POST['email'];
       $email = mysql_real_escape_string($email);	
    }
    if(isset($_POST['pwd']))
    {
       $pwd= $_POST['pwd'];    
       $pwd = md5(mysql_real_escape_string($pwd));
    }
    
    if(isset($_POST['devicetoken']))
    {
        $devicetoken = $_POST['devicetoken'];
    }
    if(isset($_POST['devicetype']))
    {
        $devicetype= $_POST['devicetype'];
    }	
    if(isset($_POST['lat']))
    {
        $lat = $_POST['lat'];
    }
    if(isset($_POST['lng']))
    {
        $lng = $_POST['lng'];
    }    
    $q = "SELECT * FROM users WHERE email = '$email' AND password = '$pwd'";
    $res=mysql_query($q);
    if(mysql_num_rows($res)>0)
    {
		$row=mysql_fetch_assoc($res);	
		$id = $row["userid"];
		$q = "UPDATE users SET isloggedin = '1', devicetoken = '$devicetoken', devicetype = '$devicetype', lat = $lat, lng = $lng  WHERE userid = $id";        
		mysql_query($q);
		$q = "SELECT userid,fname,lname,email,photopath,location,phone,type,coinstosell,rate,lat,lng,online,isloggedin FROM users WHERE userid = $id";
		$resdetail=mysql_query($q);	
		$rowdetail=mysql_fetch_assoc($resdetail);
		$output = $rowdetail;
    }			
   echo json_encode($output); 
}

//For User Sign Up
function SignUp()
{
    $obj=new funcs_code();
    $obj->connection();	
    $output = "";				
    $fname = "";   
    $lname = "";	
    $email = "";
    $pwd = ""; 
    $photo = "";
    $imagepath = "";
    $location = "";
    $phone = "";
    $coinstosell = 0;
    $rate = 0;
    $lat = 0;
    $lng = 0;
    $devicetype = "";
    $devicetoken = "";
	
    $date = date('YmdHis');        
    if(isset($_POST["fname"]))
    {
        $fname = $_POST["fname"];
        $fname = mysql_escape_string($fname);
    } 
    if(isset($_POST["lname"]))
    {
        $lname = $_POST["lname"];
        $lname = mysql_escape_string($lname);
    }	
    if(isset($_POST["email"]))
    {
        $email = $_POST["email"];
        $email = mysql_escape_string($email);
    }
    if(isset($_POST["pwd"]))
    {
        $pwd = $_POST["pwd"];
        $pwd = mysql_escape_string(md5($pwd));
    }
    if(isset($_POST["location"]))
    {
        $location = $_POST["location"];
    }
    if(isset($_POST["phone"]))
    {
        $phone= $_POST["phone"];
    }
    if(isset($_POST["coinstosell"]))
    {
        $coinstosell = $_POST["coinstosell"];
    }
	if(isset($_POST["rate"]))
    {
        $rate = $_POST["rate"];
    }
    if(isset($_POST["lat"]))
    {
        $lat = $_POST["lat"];
    }
    if(isset($_POST["lng"]))
    {
        $lng = $_POST["lng"];
    }
    if(isset($_POST['photo']))
    {
        $photo = $_POST['photo'];
    }
    if(isset($_POST['devicetoken']))
    {
        $devicetoken = $_POST['devicetoken'];
    }
    if(isset($_POST['devicetype']))
    {
        $devicetype= $_POST['devicetype'];
    }   
    
    $q = "SELECT * FROM users WHERE email = '$email'";
    $res=mysql_query($q);	
    $row=mysql_fetch_row($res);
    if(mysql_num_rows($res)==0)
    {	
		if($imagepath == "")
		{
			if ($photo != "")
			{
				$img = imagecreatefromstring(base64_decode($photo));
				if($img != false)
				{
					$dt = date('YmdHis'); 
					$rn = mt_rand();
					$imagepath="upload/photos/".$dt.$rn.".jpg";
					$dirpath = '../../'.$imagepath;			
					imagejpeg($img, $dirpath);
				}          
			}
		}	
		
        $q = "INSERT INTO users VALUES ('','$fname','$lname','$email','','','$pwd','$imagepath','$location','$phone','',0,0,$lat,$lng,
'$devicetoken','$devicetype','0','0','{$date}',10)";

        if(mysql_query($q))
        {
            $id = mysql_insert_id();
            $q = "UPDATE users SET isloggedin = '1' WHERE userid = $id";        
            mysql_query($q);
            
            $q = "SELECT userid,fname,lname,email,photopath,location,phone,type,coinstosell,rate,lat,lng,online,isloggedin FROM users WHERE userid = $id";
			$resdetail = mysql_query($q);	
			$rowdetail = mysql_fetch_assoc($resdetail);
            $output = $rowdetail;
        }
        else
        {
            $output = "0";		
        }
    }
    else
    {
       $output = "-1"; // Email Already Registered		
    }

    echo json_encode($output); 
}

function SocialSignIn()
{
    $obj=new funcs_code();
   	$obj->connection();	
	$output = "";
	$date = date('YmdHis');
	$fname = "";
	$lname = "";
	$email = "";
	$pwd = "";	
	$location = "";
        $imagepath = "";
        $fbid = "";
        $linkedinid = "";
	$devicetoken = "";
	$devicetype = "";
	$lat = 0;
        $lng = 0;	
	$coinstosell = 0;
	$rate = 0;
	if(isset($_POST["fname"]))
	{
	   $fname = $_POST["fname"];	
	}
	if(isset($_POST["lname"]))
	{
	   $lname = $_POST["lname"];	
	}
	if(isset($_POST["email"]))
	{
	    $email = $_POST["email"];
        $email = mysql_escape_string($email);	   
	}
	if(isset($_POST["photopath"]))
	{
	   $imagepath = $_POST["photopath"];	
	}
   if(isset($_POST["fbid"]))
   {
       $fbid = $_POST["fbid"];
       $pwd = mysql_escape_string(md5($fbid));	   
    }
    if(isset($_POST["linkedinid"]))
    {
       $linkedinid = $_POST["linkedinid"];
       $pwd = mysql_escape_string(md5($linkedinid));	   
    }
    if(isset($_POST['devicetoken']))
    {
        $devicetoken = $_POST['devicetoken'];
    }
    if(isset($_POST['devicetype']))
    {
        $devicetype= $_POST['devicetype'];
    }	
    if(isset($_POST["usertype"]))
    {
	   $usertype = $_POST["usertype"];	
    }
    if(isset($_POST["lat"]))
    {
        $lat = $_POST["lat"];
    }
    if(isset($_POST["lng"]))
    {
        $lng = $_POST["lng"];
    }
	
    if(isset($_POST["location"]))
    {
        $location = $_POST["location"];
    }
	
	if($fbid != "")
	{
		$q = "SELECT * FROM users WHERE email = '$email' AND fbid = '$fbid'";
	}
	else if($linkedinid != "")
	{
		$q = "SELECT * FROM users WHERE email = '$email' AND linkedinid = '$linkedinid'";
	}
	$res=mysql_query($q);	
	$row=mysql_fetch_row($res);	
	if(mysql_num_rows($res)==0)
	{	
		$q = "INSERT INTO users VALUES ('','$fname','$lname','$email','$fbid','$linkedinid','$pwd','$imagepath','$location','','',0,0,$lat,$lng,
'$devicetoken','$devicetype','0','0','{$date}',10)";
		if(mysql_query($q))
		{			
			$id = mysql_insert_id();			
			$q = "UPDATE users SET isloggedin = '1' WHERE userid = $id";        
            mysql_query($q);
             
            $q = "SELECT userid,fname,lname,email,photopath,location,phone,type,coinstosell,rate,lat,lng,online,isloggedin FROM users WHERE userid = $id";
			$resdetail = mysql_query($q);	
			$rowdetail = mysql_fetch_assoc($resdetail);
            $output = $rowdetail;
		}
		else
		{
			$output = "0";		
		}
	}
	else
	{
		$userid = $row["0"];
		$q = "UPDATE users SET isloggedin = '1', devicetoken = '$devicetoken', devicetype = '$devicetype', 
			  lat = $lat, lng = $lng, location = '$location', photopath = '$imagepath' WHERE userid = $userid";        
		mysql_query($q);
		
		$q = "SELECT userid,fname,lname,email,photopath,location,phone,type,coinstosell,rate,lat,lng,online,isloggedin FROM users WHERE userid = $id";
		$resdetail = mysql_query($q);	
		$rowdetail = mysql_fetch_assoc($resdetail);
		$output = $rowdetail;			
	}
	echo json_encode($output);	
}

//To update password
function ChangePassword()
{
    $obj=new funcs_code();
    $obj->connection();	
    $output = "0";
    $id = 0;				
    $newpassword = "";
    $oldpassword = "";
    
	
    if(isset($_POST["id"]))
    {
       $id = $_POST["id"];
    }
    if(isset($_POST["oldpassword"]))
    {
	$oldpassword = $_POST["oldpassword"];
        $oldpassword =  mysql_escape_string(md5($oldpassword));
    }
    if(isset($_POST["newpassword"]))
    {
       $newpassword = $_POST["newpassword"];
       $newpassword = mysql_escape_string(md5($newpassword));
    }
	
	$sql="SELECT * FROM users WHERE password = '$oldpassword' AND userid = $id";
    $res=mysql_query($sql);
    $result=mysql_fetch_row($res);
    if(mysql_num_rows($res) > 0)
    {
	   $pass=$result["6"];
	   if($pass == $oldpassword)
	   {
		  $q = "UPDATE users SET password = '$newpassword' WHERE userid = $id";
		  if(mysql_query($q))
		  {
			$output = "1";
		  }	
	   }           
	}
    echo json_encode($output); 
}

function UpdateUserProfile()
{
    $obj=new funcs_code();
    $obj->connection();	
    $output = "";
    $userid = 0;	
    $fname = "";
    $lname = "";    
    $email = "";
    $photo = "";
    $imagepath = "";
    $location = "";
    $phone = "";
    $lat = 0;
    $lng = 0;	
    $devicetype = "iphone";
    $devicetoken = "";                  
    $date = date('YmdHis'); 
    if(isset($_POST["userid"]))
    {
        $userid = $_POST["userid"];
    }	
    if(isset($_POST["fname"]))
    {
        $fname = $_POST["fname"];
        $fname = mysql_escape_string($fname);
    } 
    if(isset($_POST["lname"]))
    {
        $lname = $_POST["lname"];
        $lname = mysql_escape_string($lname);
    }	
    if(isset($_POST["email"]))
    {
        $email = $_POST["email"];
        $email = mysql_escape_string($email);
    }    
    if(isset($_POST["location"]))
    {
        $location = $_POST["location"];
    }
    
    if(isset($_POST["phone"]))
    {
        $phone= $_POST["phone"];
    }
    
    if(isset($_POST["lat"]))
    {
        $lat = $_POST["lat"];
    }
    if(isset($_POST["lng"]))
    {
        $lng = $_POST["lng"];
    }
    if(isset($_POST['photo']))
    {
        $photo = $_POST['photo'];
    }   		
		
	$q = "SELECT * FROM users WHERE email = '$email' AND userid <> $userid";
	$res=mysql_query($q);
	$row=mysql_fetch_row($res);	
	if(mysql_num_rows($res)==0)
	{	
		if($imagepath == "")
		{
			if ($photo != "")
			{
				$img = imagecreatefromstring(base64_decode($photo));
				if($img != false)
				{
					$dt = date('YmdHis'); 
					$rn = mt_rand();
					$imagepath="upload/photos/".$dt.$rn.".jpg";
					$dirpath = '../../'.$imagepath;			
					imagejpeg($img, $dirpath);
					$q = "UPDATE users SET photopath = '$imagepath' WHERE userid = $userid";			
					mysql_query($q);
				}
			}
		}
	$q = "UPDATE users SET fname = '$fname', lname = '$lname',email = '$email', location = '$location', phone = '$phone', lat = $lat, lng = $lng, status = 10 
WHERE userid = $userid";

		if(mysql_query($q))
		{
		   $output = "1";	
		}
		else 
		{
		   $output = "0";		
		}
	}
	else
	{
	   $output = "-1"; // Email already registered.
	}
	echo json_encode($output);
}

//For Sign Out
function SignOut()
{
    $obj=new funcs_code();
    $obj->connection();	
    $output = "0";
    $id = 0;
    $usertype = ""; 
    if(isset($_POST["id"]))
    {
        $id = $_POST["id"];
    }	
	$q = "UPDATE users SET isloggedin = '0' WHERE userid = $id";
    mysql_query($q);
    $output = "1";    
    echo json_encode($output);
}

function Search()
{
$obj=new funcs_code();
$obj->connection();		
$lat = 0;
$lng = 0;
$userid = 0;
$type= "";
$coinstosell = 0;
$rate = 0;
$lat1 = 0;
$lat2 = 0;
$lng1 = 0;
$lng2 = 0;
$buyer = "";
$seller = "";
$milesDistance = 5000;
	if(isset($_GET["userid"]))
	{   
	   $userid = $_GET["userid"];
	}
	if(isset($_GET["lat"]))
	{   
	   $lat = $_GET["lat"];
	}
	if(isset($_GET["lng"]))
	{   
	   $lng = $_GET["lng"];
	}
	if(isset($_GET["keywords"]))
	{   
	   $keywords = $_GET["keywords"];
	}	
	if(isset($_GET["type"]))
	{   
	   $type = $_GET["type"];
	}
        if(isset($_GET["coinstosell"]))
	{   
	   $coinstosell = $_GET["coinstosell"];
	}
        if(isset($_GET["rate"]))
	{   
	   $rate= $_GET["rate"];
	}
	if(isset($_GET["buyer"]))
	{   
	   $buyer = $_GET["buyer"];
	}
        if(isset($_GET["seller"]))
	{   
	   $seller = $_GET["seller"];
	}
	$q = "UPDATE users SET type = '$type', coinstosell = $coinstosell, rate = $rate, lat = $lat, lng = $lng WHERE userid = $userid";
	mysql_query($q);

	$milesPerDegree = 0.868976242 / 60.0 * 1.2;	
	$degrees = $milesPerDegree * $milesDistance;
	$lng1 = $lng - $degrees;
	$lng2 = $lng + $degrees;
	$lat1 = $lat - $degrees;
	$lat2 = $lat + $degrees;
	
	$q = "SELECT 
			users.userid,
			users.fname,
			users.lname,
			users.email,
			users.photopath,
			users.location,
			users.lat,
			users.lng,
			users.type,
			users.online,			
			users.phone,
			users.coinstosell,
			users.rate,
			users.isloggedin,
			IFNULL(favorites.favoriteid,0) AS favoriteid			
		FROM
			users
		LEFT OUTER JOIN
			favorites
		ON
			(favorites.senderid = users.userid AND favorites.receiverid = $userid)
		OR  (favorites.receiverid = users.userid AND favorites.senderid = $userid)
		WHERE users.status <> 0 AND users.userid NOT IN(SELECT blockeduserid FROM blockedusers WHERE senderid = $userid) 
		AND users.userid NOT IN(SELECT senderid FROM favorites WHERE receiverid = $userid) 
                AND users.userid NOT IN(SELECT receiverid FROM favorites WHERE senderid = $userid)
                AND users.userid <> $userid ";
                   
	if($keywords == "" && $lat > 0 && $lng > 0)
	{
		$q = $q."AND ((lat > $lat1 AND lat < $lat2) AND (lng > $lng1 AND lng < $lng2))";
	}
	if($buyer == "buyer" && $seller == "")
	{
		$q = $q." AND type = 'buyer'";
	}
    else if($buyer == "" && $seller == "seller")
	{
		$q = $q." AND type = 'seller'";
	}
    else if($buyer == "buyer" && $seller == "seller")
	{
		$q = $q." AND type = 'buyer' OR type = 'seller'";
	}

	if($keywords == "worldwide")
	{	
		$q = $q." ORDER BY users.userid limit 1000";
	}

	$res=mysql_query($q);
$users = Array();		
	if(mysql_num_rows($res) > 0) 
	{		
		$users= array();
		while($user = mysql_fetch_assoc($res)) {                            
			$users[] = array('user'=>$user);
		}
		
	}
        header('Content-type: application/json');
        echo json_encode(array('users'=>$users));			
}

function MarkAsFavorites()
	{
		$obj=new funcs_code();
   		$obj->connection();
		$output = "0";
		$date = date('YmdHis');	
		$senderid = 0;
        $receiverid = 0; 
	    
		if(isset($_POST["senderid"]))
		{
			$senderid= $_POST["senderid"];
		}
		if(isset($_POST["receiverid"]))
		{
			$receiverid = $_POST["receiverid"];
		}
		
		$q = "SELECT * FROM favorites WHERE (senderid = $senderid AND receiverid = $receiverid) OR (senderid = $receiverid AND receiverid = $senderid)";		
		$res = mysql_query($q);				
		if(mysql_num_rows($res) == 0)
		{	
			$q= "INSERT INTO favorites VALUES ('',$senderid,$receiverid,'{$date}',10)";
			if(mysql_query($q))
			{
				$output = mysql_insert_id();
                $q = "SELECT * FROM users WHERE userid = $senderid";
				$result = mysql_query($q);					
				if(mysql_num_rows($result) > 0)
				{
					$row = mysql_fetch_assoc($result);
					$fname = $row["fname"];
					$lname = $row["lname"];
				}
                $q = "SELECT * FROM users WHERE userid = $receiverid";
				$res1 = mysql_query($q);					
				if(mysql_num_rows($res1) > 0)
				{
					$row1 = mysql_fetch_assoc($res1);	
					$devicetoken = $row1["devicetoken"];
					$devicetype = $row1["devicetype"];
					$name = $fname." ".$lname;
					$message = $name." marked you as favorite.";
					if($devicetype == "ios")
					{
						iospushnotification($devicetoken, $message);
					}
					else if($devicetype == "android")
					{
						
					}
				}	
			} 			
		} 
		else 
		{
			$output = "-1";
		}
	echo json_encode($output); 
}

function MarkAsUnFavorites()
{
	$obj=new funcs_code();
	$obj->connection();
	$output = "";		
	$favoriteid= $_POST["favoriteid"];
	$q= "DELETE FROM favorites WHERE favoriteid = $favoriteid";
	if(mysql_query($q))
	{			
	   $output = "1";		
	}
	else
	{
	   $output = "0";		
	}
		
	echo json_encode($output); 
}
	
function GetFavorites()
{
	$obj=new funcs_code();
	$obj->connection();
	$userid = 0; 		
	if(isset($_GET["userid"]))
	{
		$userid = $_GET["userid"];
	}
	$favorites = array();
	if($userid > 0)
	{                  
		$q = "SELECT 
			userid, fname, lname, email, photopath, lat, lng, online,type,coinstosell,rate,location,phone,
			IFNULL(favorites.favoriteid,0) as favoriteid	                         
		      FROM 
			favorites 
		      INNER JOIN users ON (favorites.senderid = users.userid AND favorites.receiverid = $userid)
		      OR (favorites.receiverid = users.userid AND favorites.senderid = $userid)
		      WHERE (favorites.senderid = $userid OR favorites.receiverid = $userid)";	
		$res = mysql_query($q);
		if(mysql_num_rows($res) > 0)
		{	
			while($favorite = mysql_fetch_assoc($res)) {
				   $favorites[] = array('favorite'=>$favorite);
				} 
		}   
	}         
	header('Content-type: application/json');     
	echo json_encode(array('favorites'=>$favorites));
}

function ForgetPassword()
{
	$obj=new funcs_code();
	$obj->connection();		  
	$pwd = mt_rand(99999,9999999);
	$output = "0";	
	$userid = 0;	
	$email = "";
	$ency_pwd = "";	
	$ency_pwd = mysql_escape_string(md5($pwd));
	if(isset($_POST["email"]))
	{
		$email = $_POST["email"];
		$email = mysql_escape_string($email);
	}
	
	if($email != "")
	{
	    $q ="SELECT * FROM users WHERE email = '$email'";
	    $result =  mysql_query($q);					
	    if(mysql_num_rows($result) > 0)
	    {
			$q = "UPDATE users SET password = '$ency_pwd' WHERE email = '$email'";
			if(mysql_query($q))
			{
				$output = "1";
				$message = "<b>Your new password is: ".$pwd."</b><br /><br />";
				$message = $message."Your password has been changed. You don't need to do anything, this message is simply a notification to protect the security of your account. Your new password has been activated. If it does not work on your first try, please try again later. "."<br /><br />";
				$message = $message."The Retirely Team";
				$to = $email;
				$subject = "Your PinBitCoins password has been changed";
				$from ="info@linkites.com";    			
				$headers .= ' MIME-Version: 1.0'. "\r\n";
				$headers .= 'Content-Type: text/html; charset=ISO-8859-1'. "\r\n"; 
				$headers .= 'From:PinBitCoins<' . $from.'>';
				@mail($to,$subject,$message,$headers);
			}	
			else
			{
				$output = "0";		
			}
		}
		else
		{
			$output = "-2";	
		}
	}
	else
	{
	   $output = "-1";	
	}
	echo json_encode($output); 
}

function GetUserDetail()
{
	$obj=new funcs_code();
	$obj->connection();	
	$output = "";
	$userid = 0;
	if(isset($_GET["userid"]))
	{
		$userid = $_GET["userid"];
	}
	$q = "SELECT * FROM users WHERE userid = $userid";
	$res1=mysql_query($q);	
	$users = array();			
	if(mysql_num_rows($res1) > 0)
	{
		 while($user = mysql_fetch_assoc($res1)) {
			 $users[] = array('user'=>$user);
		 }				    			   
	}
	header('Content-type: application/json');     
	echo json_encode(array('users'=>$users));
}

function MarkAsBlocked()
{
	$obj=new funcs_code();
   	$obj->connection();
	$date = date('YmdHis');
	$output = "0";
	$senderid = 0; 
	$blockeduserid = "";
	if(isset($_POST["senderid"]))
	{
		$senderid = $_POST["senderid"];
	}	
	if(isset($_POST["blockeduserid"]))
	{
		 $blockeduserid = $_POST["blockeduserid"];
	}
	
	$q = "SELECT * FROM blockedusers WHERE senderid = $senderid AND blockeduserid = $blockeduserid";
	$res = mysql_query($q);          
	if(mysql_num_rows($res) == 0)
	{
		$q= "INSERT INTO blockedusers VALUES ('',$senderid, $blockeduserid,'{$date}',10)";
		if(mysql_query($q))
		{
			$output = "1";
		}
	}
	echo json_encode($output);
}

function GetBlockedUsers()
{
    $obj=new funcs_code();
    $obj->connection();
    $output = "0";
    $senderid = 0;
    if(isset($_GET["senderid"]))
    {
       $senderid = $_GET["senderid"];
    }
	
	$q = "SELECT * FROM blockedusers WHERE senderid = $senderid";
	$res = mysql_query($q);			
	if(mysql_num_rows($res) > 0)
	{
		while($result = mysql_fetch_assoc($res)) {
			$output = $output.$result["blockeduserid"].",";
		}
		$output = substr($output, 0, -1);		
	} 
	echo $output;
}

function iospushnotification($deviceToken ,$msg)
{
    $deviceToken = str_replace("<","",$deviceToken);
    $deviceToken = str_replace(">","",$deviceToken);
    $deviceToken = str_replace(" ","",$deviceToken);
    $deviceToken = $deviceToken; 
	$payload['aps'] = array(
	'alert' => $msg,
	'badge' => 1, 
	'sound' => 'default'
	);
	$passphrase = 'linkites';	
	$payload = json_encode($payload);
	$apnsHost = 'gateway.sandbox.push.apple.com';
	$apnsPort = 2195;
	$apnsCert = 'PinBitCoinDev_dec_17_2013.pem';
	$streamContext = stream_context_create();
	stream_context_set_option($streamContext, 'ssl', 'local_cert', $apnsCert);
        stream_context_set_option($streamContext, 'ssl', 'passphrase', $passphrase);
	$apns = stream_socket_client('ssl://' . $apnsHost . ':' . $apnsPort, $error,$errorString,60,STREAM_CLIENT_CONNECT,$streamContext); 
	$apnsMessage	 = chr(0) . chr(0) . chr(32) . pack('H*', $deviceToken) . chr(0) . chr(strlen($payload)) . $payload;
	fwrite($apns, $apnsMessage);
	@socket_close($apns);
	fclose($apns);  
}

function iospushnotificationtest()
{
    $deviceToken = '<5b69ce7a 070dd0e5 4f33b1c4 477d510e 8f987dd0 ac37635c 9c6bdb82 6891ebf3>';
    $deviceToken = str_replace("<","",$deviceToken);
    $deviceToken = str_replace(">","",$deviceToken);
    $deviceToken = str_replace(" ","",$deviceToken);
    $deviceToken = $deviceToken; 
	$msg = "Hello Mr. Granade";
	$payload['aps'] = array(
	'alert' => $msg,
	'badge' => 1, 
	'sound' => 'default'
	);
	$passphrase = 'linkites';	
	$payload = json_encode($payload);
	$apnsHost = 'gateway.sandbox.push.apple.com'; 
	$apnsPort = 2195;
	$apnsCert = 'PinBitCoinPro_dec_17_2013.pem';
	$streamContext = stream_context_create();
	stream_context_set_option($streamContext, 'ssl', 'local_cert', $apnsCert);
        stream_context_set_option($streamContext, 'ssl', 'passphrase', $passphrase);
	$apns = stream_socket_client('ssl://' . $apnsHost . ':' . $apnsPort, $error,$errorString,60,STREAM_CLIENT_CONNECT,$streamContext); 
	$apnsMessage	 = chr(0) . chr(0) . chr(32) . pack('H*', $deviceToken) . chr(0) . chr(strlen($payload)) . $payload;
	fwrite($apns, $apnsMessage);
	@socket_close($apns);
	fclose($apns); 

}

function GetChatHistory()
{  
    $obj=new funcs_code();
    $obj->connection();	
    $output = "";
    $senderid = 0;
    $receiverid = 0;
    if(isset($_GET["senderid"]))
    {
        $senderid = $_GET["senderid"];
    }  
   if(isset($_GET["receiverid"]))
    {
        $receiverid = $_GET["receiverid"];
    }   
    $q = "SELECT * FROM chats WHERE ((senderid = $senderid AND receiverid = $receiverid) OR (senderid = $receiverid AND receiverid = $senderid))";
    $res1=mysql_query($q);	
    $chats = array();			
    if(mysql_num_rows($res1) > 0)
    {
        while($chat = mysql_fetch_assoc($res1)) {
            $chats[] = array('chat'=>$chat);
        }				    			   
   }
   header('Content-type: application/json');     
   echo json_encode(array('chats'=>$chats));
}

function ContactUs()
{
	$email = '';
	$subject = '';
	$message = '';
	if(isset($_POST["email"]))
	{
		$email = $_POST["email"];
		$email = mysql_escape_string($email);
	}
	if(isset($_POST["subject"]))
	{
		$subject = $_POST["subject"];
	}
	if(isset($_POST["message"]))
	{
		$message = $_POST["message"];
	}
	if($email != "")
	{           
		$output = "1";
		$to = 'virendra.chouhan@linkites.com';
		$from = $email;    			
		//$headers .= ' MIME-Version: 1.0'. "\r\n";
		$headers .= 'Content-Type: text/html; charset=ISO-8859-1'. "\r\n"; 
		$headers .= 'From:<' . $from.'>';
		@mail($to,$subject,$message,$headers);    		 
	}
	else
	{
	   $output = "-1";	
	}
	echo json_encode($output); 
}

function UpdatePhoto()
{
    $obj=new funcs_code();
    $obj->connection();	
    $output = "0";    
    $userid = 0;
    $photo = "";
    $imagepath = "";
    if(isset($_POST['photo']))
    {
        $photo = $_POST['photo'];
    }    
    if(isset($_POST['userid']))
    {
        $userid = $_POST['userid'];
    }
    if($imagepath == "")
    {
		if ($photo != "")
		{            
			$img = imagecreatefromstring(base64_decode($photo));
			if($img != false)
			{                
				$dt = date('YmdHis'); 
				$rn = mt_rand();				
				$imagepath="upload/photos/".$dt.$rn.".jpg";
				$dirpath = '../../'.$imagepath;			
				imagejpeg($img, $dirpath);
				$q = "UPDATE users SET photopath = '$imagepath' WHERE userid = $userid";
				mysql_query($q);
				$output = "1";					
			}
		}
    }
    echo json_encode($output); 	
}

function UpdateSettings()
{
    $obj=new funcs_code();
    $obj->connection();	
    $output = "0";    
    $userid = 0;
    $type= "";
    $coinstosell = 0;
    $rate = 0;
    $lat = 0;
    $lng = 0;
    if(isset($_POST['userid']))
    {
        $userid = $_POST['userid'];
    }
    if(isset($_POST["type"]))
    {   
       $type = $_POST["type"];
    }
    if(isset($_POST["coinstosell"]))
    {   
       $coinstosell = $_POST["coinstosell"];
    }
    if(isset($_POST["rate"]))
    {    
       $rate= $_POST["rate"];
    }
    if(isset($_POST["lat"]))
    {   
       $lat = $_POST["lat"];
    }
    if(isset($_POST["lng"]))
    {   
       $lng = $_POST["lng"];
    }  
    $q = "UPDATE users SET type = '$type', coinstosell = $coinstosell, rate = $rate, lat = $lat, lng = $lng WHERE userid = $userid";
    mysql_query($q); 
    $output = "1";
    echo json_encode($output); 	   
    
}