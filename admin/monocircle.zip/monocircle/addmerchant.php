<?php 
session_start();
if($_SESSION["myusername"]=="" && $_SESSION["mypassword"]=="")
{
	header("location:index.php");
} 
include('in_header.php');
include('function.php');
$error='';
if(isset($_POST["submit"])=="Submit")
{
	$error = AddMerchant();
}
?>
<div class="right">      
    <div class="center_mess">Add Merchant</div>
	<form method="post" enctype="multipart/form-data">
		<table width="100%" border="0" cellspacing="2" cellpadding="5" style="text-align:left;vertical-align:top">                      
		<tr>
			<td valign="top" class="lable" width="180px;">Name*:</td>
			<td><input type="text" name="username" id="username" class="maxwidth" required></input></td>           
		</tr>
		<tr>
			<td valign="top" class="lable">Email*:</td>
			<td><input type="text" name="email" id="email" class="maxwidth" required email></input></td>
		</tr>			
		<tr>
			<td valign="top" class="lable">Password*:</td>
			<td><input type="password" name="password" id="password" class="maxwidth" required></input></td>
		</tr> 						
		<tr>
			<td></td>
			<td align="left" style="padding-top:10px;"><input type="submit" name="submit" id="submit" value="Submit"></td></tr>
		<tr>
			<td></td>
			<td align="left" style="padding-top:10px;"><?php if(isset($error)){echo "<P>".$error."</p>";}?></td></tr>
		</table>				
	</form>			
</div>
<?php include('in_footer.php'); ?>