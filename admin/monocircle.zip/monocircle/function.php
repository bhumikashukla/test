<?php
define("dba","monocircle");
define("host","localhost");
define("user","root");
define("pass","");
function connection()
{
 $conn=mysql_connect(host,user,pass) or die(mysql_error());
 $dba=mysql_select_db(dba,$conn) or die(mysql_error()); 
}

function AddEditOffer()
{
	connection();
	$output = "";
	$offerid = $_POST["offerid"];
	$merchantid = $_POST["merchantid"];
	$offername = $_POST["offername"];
	$discount = $_POST["discount"];
    $priceafterdiscount = $_POST["priceafterdiscount"];
	$description = $_POST["description"];
	$oldphotopath = $_POST["oldphotopath"];
	$date = date("YmdHis");
	if($offerid == "0")
	{
	    if ((($_FILES["photo"]["type"] == "image/gif") || ($_FILES["photo"]["type"] == "image/jpeg") 
		|| ($_FILES["photo"]["type"] == "image/jpg") || ($_FILES["photo"]["type"] == 	"image/png")) && ($_FILES["photo"]["size"] < 20000000))
		{
				if ($_FILES["photo"]["error"] > 0)
				{
					$output = "Error: " . $_FILES["photo"]["error"] . "<br />";
				}
			   else
				{   
				   date_default_timezone_set('UTC');
		           $dt = date('YmdHis');
				   $rn = mt_rand();        
				   $file_name="upload/photos/offers/" .$dt.$rn.".jpg";
				   move_uploaded_file($_FILES["photo"]["tmp_name"],  $file_name);
				}
		}
		else
		{
			$output = "Error: Invalid file format.";
		}
		if($output == "")
		{
			$q = "INSERT INTO offers VALUES ('',$merchantid,'$offername',$discount,'$file_name',$priceafterdiscount,'$description','{$date}',10)";			
			if(mysql_query($q))
			{	
				$id = mysql_insert_id();
				$output = "Offer added successfully.";		
			}
			else
			{
			   $output = "Error in processing request. Please try again.";		
			}
		}		
	}
	else
	{
		if($_FILES["photo"]["size"] > 0)
		{
			if ((($_FILES["photo"]["type"] == "image/gif") || ($_FILES["photo"]["type"] == "image/jpeg") 
			|| ($_FILES["photo"]["type"] == "image/jpg") || ($_FILES["photo"]["type"] == 	"image/png")) && ($_FILES["photo"]["size"] < 20000000))
			{
			
					if ($_FILES["photo"]["error"] > 0)
					{
						$output = "Error: " . $_FILES["photo"]["error"] . "<br />";
					}
				   else
					{   
					   date_default_timezone_set('UTC');
					   $dt = date('YmdHis');
					   $rn = mt_rand();        
					   $file_name="upload/photos/offers/" .$dt.$rn.".jpg";
					   move_uploaded_file($_FILES["photo"]["tmp_name"],  $file_name);
					   $q = "UPDATE offers SET photopath = '$file_name' WHERE offerid = $offerid";
					   mysql_query($q);
					   if($oldphotopath != "")
					   {
							@unlink($oldphotopath);
					   }
					}
			}
			else
			{
				$output = "Error: Invalid file format.";
			}
		}
		if($output == "")
		{
			$q = "UPDATE offers SET offername = '$offername', description = '$description', discount = $discount, priceafterdiscount = $priceafterdiscount WHERE offerid = $offerid";	
	
			if(mysql_query($q))
			{			
				$output = "Offer updated successfully.";		
			}
			else
			{
			   $output = "Error in processing request. Please try again.";		
			}
		}
	}
	return $output; 
}

function AddMerchant()
{
	connection();
	$output = "";
	$username = $_POST["username"];
	$email = $_POST["email"];	
	$password = $_POST["password"];
	$password = md5($password);
	$date = date("Ymd");	
	$q = "SELECT * FROM adminusers WHERE email = '$email'";
    $res=mysql_query($q);
    if(mysql_num_rows($res) == 0)
    {
		$q1 = "SELECT * FROM adminusers WHERE username = '$username'";
		$res1=mysql_query($q1);
		if(mysql_num_rows($res1) == 0)
		{
			$q2 = "INSERT INTO adminusers VALUES ('','$username','$email','$password','merchant','{$date}',10)";	
			if(mysql_query($q2))
			{	
				$id = mysql_insert_id();
				$output = "Merchant added successfully.";		
			}
			else
			{
			   $output = "Error in processing request. Please try again.";		
			}
		}
		else
		{
			$output = "Username already register.";
		}
	}
	else
	{
		$output = "Email already register.";
	}	
	return $output; 
}

function getUserType(){
	$adminuserid=$_SESSION['admin_id'];
	$usertyperow=mysql_fetch_assoc(mysql_query("select role from adminusers where adminuserid= $adminuserid limit 1")) or die(mysql_error());
	$usertype=$usertyperow["role"];
	return $usertype;
}