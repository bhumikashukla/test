<?php 
session_start();
if($_SESSION["myusername"]=="" && $_SESSION["mypassword"]=="")
{
	header("location:index.php");
} 
include('in_header.php');
include('function.php');
$error='';
if(isset($_POST["submit"])=="Submit")
{
	$error = AddEditOffer();
}
?>
<?php
if(isset($_GET["id"]) != "")
{
	$id = $_GET["id"];
}
else
{
	$id = 0;
}
$str="SELECT * FROM offers WHERE offerid = $id";
$result=mysql_query($str);
$rn = mysql_num_rows($result);
if($rn!="0")
{
	$row = mysql_fetch_assoc($result);
	$id = $row["offerid"];
	$merchantid = $row["merchantid"];
	$offername = $row["offername"];
	$discount = $row["discount"];
    $priceafterdiscount = $row["priceafterdiscount"];
	$photopath = $row["photopath"];
	$description = $row["description"];
}
?>
<?php if($rn == "0") {?>
<div class="right">      
    <div class="center_mess">Add Offer</div>
    	<form method="post" enctype="multipart/form-data">
            <table width="100%" border="0" cellspacing="2" cellpadding="5" style="text-align:left;vertical-align:top"> 
			<?php  
				$usertype=getUserType();
			   if($usertype!="merchant") { ?>
		    <tr>
				<td valign="top" class="lable">Marchant*:</td>
				<td>
					 <?php $merchants_rows=mysql_query("select adminuserid , username from adminusers where role = 'merchant'") ; ?>
							<select name="merchantid" id="merchantid" class="maxwidth" required>
							<option value="">Select Merchant</option>
							<?php while($mer=mysql_fetch_array($merchants_rows)) {
						   ?>
						   <option value="<?php echo $mer["adminuserid"]; ?>"><?php echo $mer['username']; ?></option>
						   <?php } ?>
					</select>
				</td>								   
			</tr>
			<?php } else { ?>
				<input type="hidden" name="merchantid" id="merchantid" value="<?php echo  $_SESSION['admin_id']; ?>" /> 
			<?php }	?>
            <tr>
				<td valign="top" class="lable" width="180px;">Offer Name*:</td>
				<td><input type="text" name="offername" id="offername" class="maxwidth" required></input></td>           
            </tr>						
            <tr>
				<td valign="top" class="lable">Discount(In %)*:</td>
				<td><input type="text" name="discount" id="discount" class="maxwidth" required></input></td>
			</tr> 
			<tr>
				<td valign="top" class="lable">Price After Discount*:</td>
				<td>
					<input type="text" name="priceafterdiscount" id="priceafterdiscount" class="maxwidth" required></input>
				</td>
			</tr>
			<tr>
				<td class="lable">Photo*:</td>
				<td><input name="photo" id="photo" type="file" required/></td>
			</tr>
			<tr>
				<td valign="top" class="lable">Description:</td>
				<td><textarea name="description" id="description" rows="7" cols="41"></textarea></td>
			</tr>			
            <tr>
				<td></td>
				<td align="left" style="padding-top:10px;"><input type="submit" name="submit" id="submit" value="Submit"></td></tr>
            <tr>
				<td></td>
				<td align="left" style="padding-top:10px;"><?php if(isset($error)){echo "<P>".$error."</p>";}?></td></tr>
            </table>
            <input type="hidden" name="offerid" id="offerid" value="0" /> 
            <input type="hidden" name="oldphotopath" id="oldphotopath" value="" />			
        </form>			
</div><!-- /right -->
<?php }else{?>	
 <div class="right">      
    <div class="center_mess">Edit Offer</div>
    	<form method="post" enctype="multipart/form-data">
            <table width="100%" border="0" cellspacing="2" cellpadding="5" style="text-align:left;vertical-align:top">
            <tr>
				<td valign="top" class="lable" width="180px;">Offer Name*:</td>
				<td width="350px;"><input type="text" name="offername" id="offername" class="maxwidth" value="<?php echo $offername; ?>" required></input></td>           
            </tr>						
            <tr>
				<td valign="top" class="lable">Discount(In %)*:</td>
				<td><input type="text" name="discount" id="discount" class="maxwidth" value="<?php echo $discount; ?>" required></input></td>
			</tr> 
			<tr>
				<td valign="top" class="lable">Price After Discount*:</td>
				<td colspan="2">
					<input type="text" name="priceafterdiscount" id="priceafterdiscount" value="<?php echo $priceafterdiscount; ?>" class="maxwidth" required></input>
				</td>
			</tr>
			<tr>
				<td class="lable">Photo*:</td>
				<td><input name="photo" id="photo" type="file"/></td>
				<td><img src="<?php echo $photopath; ?>" width="40px" height="40px"/></td>
			</tr>
			<tr>
				<td valign="top" class="lable">Description:</td>
				<td colspan="2"><textarea name="description" id="description" rows="7" cols="41"><?php echo $description; ?></textarea></td>
			</tr>			
            <tr>
				<td></td>
				<td align="left" style="padding-top:10px;" ><input type="submit" name="submit" id="submit" value="Submit"></td></tr>
            <tr>
				<td></td>
				<td align="left" style="padding-top:10px;"><?php if(isset($error)){echo "<P>".$error."</p>";}?></td></tr>
            </table>
            <input type="hidden" name="offerid" id="offerid" value="<?php echo $id; ?>" />
			<input type="hidden" name="merchantid" id="merchantid" value="<?php echo $merchantid; ?>" />  			
            <input type="hidden" name="oldphotopath" id="oldphotopath" value="<?php echo $photopath; ?>" />
        			
        </form>			
</div><!-- /right -->
<?php }?>	
<?php include('in_footer.php'); ?>